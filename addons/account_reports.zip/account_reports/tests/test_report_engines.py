from .common import TestAccountReportsCommon

from odoo import fields, Command
from odoo.tests import tagged

from unittest.mock import patch


@tagged('post_install', '-at_install')
class TestReportEngines(TestAccountReportsCommon):

    _test_user_groups = None  # FIXME list needed groups

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company_data['company'].write({
            'totals_below_sections': False,
            'vat': '38972223422',
            'phone': '555-555-5555',
            'email': 'test@example.com',
        })

        # necessary to ensure successful return checks
        cls.company_data['company'].write({
            'vat': 'US12345671',
            'phone': '123456789',
            'email': 'test@gmail.com',
        })

    def test_engine_tax_tags(self):
        self.env.company.account_fiscal_country_id = self.fake_country

        # Create the report.
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_tax_tags('11'),
            groupby='account_id,move_type',
        )
        test_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_tax_tags('222T'),
            groupby='parent_state,account_id',
        )
        test_line_3 = self._prepare_test_report_line(
            self._prepare_test_expression_tax_tags('3333'),
            groupby='account_id',
        )
        report = self._create_report(
            [test_line_1, test_line_2, test_line_3],
            country_id=self.fake_country.id,
        )

        # Create the journal entries.
        move = self._create_test_account_moves([
            self._prepare_test_account_move_line(    2000.0, account_code='101001', tax_tags=['11', '222T']),
            self._prepare_test_account_move_line(    1000.0, account_code='101001', tax_tags=['11', '222T']),
            self._prepare_test_account_move_line(   -3600.0, account_code='101001', tax_tags=['222T']),
            self._prepare_test_account_move_line(     600.0, account_code='101001', tax_tags=['222T', '3333']),
            self._prepare_test_account_move_line(     900.0, account_code='101002', tax_tags=['11']),
            self._prepare_test_account_move_line(    1500.0, account_code='101002', tax_tags=['11']),
        ])

        options = self._generate_options(report, '2020-01-01', '2020-01-01', default_options={'unfold_all': True})
        report_lines = report._get_lines(options)
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_lines,
            [   0,                          1],
            [
                ('test_line_1',        5400.0),
                ('101001 101001',      3000.0),
                ('Journal Entry',      3000.0),
                ('101002 101002',      2400.0),
                ('Journal Entry',      2400.0),
                ('test_line_2',           0.0),
                ('Posted',                0.0),
                ('101001 101001',         0.0),
                ('test_line_3',         600.0),
                ('101001 101001',       600.0),
            ],
            options,
        )

        # Check redirection.
        expected_redirection_values_list = [
            move.line_ids[:2] + move.line_ids[4:6],
            move.line_ids[:4],
            move.line_ids[3],
        ]
        for report_line, expected_amls in zip(report.line_ids, expected_redirection_values_list):
            report_line_dict = next(x for x in report_lines if x.name == report_line.name)
            with self.subTest(report_line=report_line.name):
                action_dict = report.action_audit_cell(options, self._get_audit_params_from_report_line(options, report_line, report_line_dict))
                self.assertEqual(move.line_ids.filtered_domain(action_dict['domain']), expected_amls)

    def test_engine_domain(self):
        domain = [('account_id.code', '=like', '1%'), ('balance', '<', 0.0)]

        # Create the report.
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_domain(domain, 'sum'),
            groupby='account_id,move_type',
        )
        test_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_domain(domain, '-sum'),
            groupby='parent_state,account_id',
        )
        report = self._create_report([test_line_1, test_line_2])

        # Create the journal entries.
        move = self._create_test_account_moves([
            self._prepare_test_account_move_line(2000.0, account_code='101001'),
            self._prepare_test_account_move_line(-300.0, account_code='101002'),
            self._prepare_test_account_move_line(-600.0, account_code='101003'),
            self._prepare_test_account_move_line(-900.0, account_code='101004'),
        ])

        # Check the values.
        options = self._generate_options(report, '2020-01-01', '2020-01-01', default_options={'unfold_all': True})
        report_lines = report._get_lines(options)
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_lines,
            [   0,                          1],
            [
                ('test_line_1',       -1800.0),
                ('101002 101002',      -300.0),
                ('Journal Entry',      -300.0),
                ('101003 101003',      -600.0),
                ('Journal Entry',      -600.0),
                ('101004 101004',      -900.0),
                ('Journal Entry',      -900.0),
                ('test_line_2',        1800.0),
                ('Posted',             1800.0),
                ('101002 101002',       300.0),
                ('101003 101003',       600.0),
                ('101004 101004',       900.0),
            ],
            options,
        )

        # Check redirection.
        expected_amls = move.line_ids.search(domain)
        for report_line in report.line_ids:
            report_line_dict = next(x for x in report_lines if x.name == report_line.name)
            with self.subTest(report_line=report_line.name):
                action_dict = report.action_audit_cell(options, self._get_audit_params_from_report_line(options, report_line, report_line_dict))
                self.assertEqual(move.line_ids.filtered_domain(action_dict['domain']), expected_amls)

    def test_engine_account_codes(self):
        # Create test account tags
        account_tags = self.env['account.account.tag']._load_records([
            {
                'xml_id': 'account_reports.account_codes_engine_test_tag1',
                'noupdate': True,
                'values': {
                    'name': "account_codes test tag 1",
                    'applicability': 'accounts',
                },
            },

            {
                'xml_id': 'account_reports.account_codes_engine_test_tag2',
                'noupdate': True,
                'values': {
                    'name': "account_codes test tag 2",
                    'applicability': 'accounts',
                },
            },
        ])

        # Create the report.
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1'),
            groupby='account_id',
        )
        test_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1C'),
            groupby='parent_state,account_id',
        )
        test_line_3 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1D'),
            groupby='account_id',
        )
        test_line_4 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'-101\(101003)'),
            groupby='account_id',
        )
        test_line_5 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'-101\(101003)C'),
            groupby='account_id',
        )
        test_line_6 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'-101\(101002,101003)'),
            groupby='account_id,move_type',
        )
        test_line_7 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('10.'),
            groupby='account_id',
        )
        test_line_8 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('10.20'),
            groupby='account_id',
        )
        test_line_9 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('10.20 - 101 + 101002'),
            groupby='account_id',
        )
        test_line_10 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'10.20 - 101\(101002)'),
            groupby='account_id',
        )
        test_line_11 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'345D\()D'),
            groupby='account_id',
        )
        test_line_12 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'345D\()C'),
            groupby='account_id',
        )
        test_line_13 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(rf'tag(account_reports.account_codes_engine_test_tag1) + tag({account_tags[1].id})'),
            groupby='account_id',
        )
        test_line_14 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'tag(account_reports.account_codes_engine_test_tag1)D'),
            groupby='account_id',
        )
        test_line_15 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(r'tag(account_reports.account_codes_engine_test_tag1)C'),
            groupby='account_id',
        )
        test_line_16 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes(rf'tag(account_reports.account_codes_engine_test_tag1)\(101)D + 101003 + tag({account_tags[1].id})\(101)C'),
            groupby='account_id',
        )

        report = self._create_report([
            test_line_1, test_line_2, test_line_3, test_line_4, test_line_5, test_line_6, test_line_7, test_line_8,
            test_line_9, test_line_10, test_line_11, test_line_12, test_line_13, test_line_14, test_line_15, test_line_16
        ])

        # Create the journal entries.
        move = self._create_test_account_moves([
            self._prepare_test_account_move_line(1000.0, account_code='100001'),
            self._prepare_test_account_move_line(2000.0, account_code='101001'),
            self._prepare_test_account_move_line(-300.0, account_code='101002'),
            self._prepare_test_account_move_line(-600.0, account_code='101003'),
            self._prepare_test_account_move_line(10000.0, account_code='10.20.0'),
            self._prepare_test_account_move_line(10.0, account_code='345D'),
        ])

        # Setup tags on accounts
        self.env['account.account'].search([('code', 'in', ('100001', '101001'))]).tag_ids = account_tags[0]
        self.env['account.account'].search([('code', 'in', ('10.20.0', '101002'))]).tag_ids = account_tags[1]

        move.line_ids[5].account_id.active = False
        # Check the values.
        options = self._generate_options(report, '2020-01-01', '2020-01-01', default_options={'unfold_all': True})
        report_lines = report._get_lines(options)

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_lines,
            [   0,                          1],
            [
                ('test_line_1',       12100.0),
                ('10.20.0 10.20.0',   10000.0),
                ('100001 100001',      1000.0),
                ('101001 101001',      2000.0),
                ('101002 101002',      -300.0),
                ('101003 101003',      -600.0),
                ('test_line_2',        -900.0),
                ('Posted',             -900.0),
                ('101002 101002',      -300.0),
                ('101003 101003',      -600.0),
                ('test_line_3',       13000.0),
                ('10.20.0 10.20.0',   10000.0),
                ('100001 100001',      1000.0),
                ('101001 101001',      2000.0),
                ('test_line_4',       -1700.0),
                ('101001 101001',     -2000.0),
                ('101002 101002',       300.0),
                ('test_line_5',         300.0),
                ('101002 101002',       300.0),
                ('test_line_6',       -2000.0),
                ('101001 101001',     -2000.0),
                ('Journal Entry',     -2000.0),
                ('test_line_7',       10000.0),
                ('10.20.0 10.20.0',   10000.0),
                ('test_line_8',       10000.0),
                ('10.20.0 10.20.0',   10000.0),
                ('test_line_9',        8600.0),
                ('10.20.0 10.20.0',   10000.0),
                ('101001 101001',     -2000.0),
                ('101002 101002',         0.0),
                ('101003 101003',       600.0),
                ('test_line_10',       8600.0),
                ('10.20.0 10.20.0',   10000.0),
                ('101001 101001',     -2000.0),
                ('101003 101003',       600.0),
                ('test_line_11',         10.0),
                ('345D 345D',            10.0),
                ('test_line_12',          0.0),
                ('test_line_13',      12700.0),
                ('10.20.0 10.20.0',   10000.0),
                ('100001 100001',      1000.0),
                ('101001 101001',      2000.0),
                ('101002 101002',      -300.0),
                ('test_line_14',       3000.0),
                ('100001 100001',      1000.0),
                ('101001 101001',      2000.0),
                ('test_line_15',          0.0),
                ('test_line_16',        400.0),
                ('100001 100001',      1000.0),
                ('101003 101003',      -600.0),
            ],
            options,
        )

        # Check redirection.
        expected_redirection_values_list = [
            move.line_ids[:5],
            move.line_ids[:5],
            move.line_ids[:5],
            move.line_ids[1:3],
            move.line_ids[1:3],
            move.line_ids[1],
            move.line_ids[4],
            move.line_ids[4],
            move.line_ids[1:5],
            move.line_ids[1] + move.line_ids[3:5],
            move.line_ids[5],
            move.line_ids[5],
        ]
        for report_line, expected_amls in zip(report.line_ids, expected_redirection_values_list):
            report_line_dict = next(x for x in report_lines if x.name == report_line.name)
            with self.subTest(report_line=report_line.name):
                action_dict = report.action_audit_cell(options, self._get_audit_params_from_report_line(options, report_line, report_line_dict))
                self.assertEqual(move.line_ids.filtered_domain(action_dict['domain']), expected_amls)

    def test_engine_external(self):
        # Create the report.
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_external('sum', [
                self._prepare_test_external_values(100.0, '2020-01-02'),
                self._prepare_test_external_values(200.0, '2020-01-03'),
                self._prepare_test_external_values(300.0, '2020-01-03'),
                self._prepare_test_external_values(299.999999999, '2020-01-05'),
            ])
        )
        test_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_external('most_recent', [
                self._prepare_test_external_values(100.0, '2020-01-02'),
                self._prepare_test_external_values(200.0, '2020-01-03'),
                self._prepare_test_external_values(300.0, '2020-01-03'),
                self._prepare_test_external_values(299.999999999, '2020-01-05'),
            ])
        )
        report = self._create_report([test_line_1, test_line_2])

        # Check the values at multiple dates.
        options = self._generate_options(report, '2020-01-01', '2020-01-01')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',           0.0),
                ('test_line_2',           0.0),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-02', '2020-01-02')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',         100.0),
                ('test_line_2',         100.0),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-03', '2020-01-03')
        report_lines = report._get_lines(options)
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_lines,
            [   0,                          1],
            [
                ('test_line_1',         500.0),
                ('test_line_2',         500.0),
            ],
            options,
        )

        # Check redirection.
        for report_line, report_line_dict in zip(report.line_ids, report_lines):
            with self.subTest(report_line=report_line.name):
                action_dict = report.action_audit_cell(options, self._get_audit_params_from_report_line(options, report_line, report_line_dict))
                self.assertRecordValues(
                    self.env['account.report.external.value'].search(action_dict['domain']),
                    [
                        {'date': fields.Date.from_string('2020-01-03')},
                        {'date': fields.Date.from_string('2020-01-03')},
                    ],
                )

        options = self._generate_options(report, '2020-01-04', '2020-01-04')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',           0.0),
                ('test_line_2',           0.0),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-02', '2020-01-04')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',          600.0),
                ('test_line_2',          500.0),
            ],
            options,
        )

        # Check redirection.
        expected_redirection_values_list = [
            [
                {'date': fields.Date.from_string('2020-01-02')},
                {'date': fields.Date.from_string('2020-01-03')},
                {'date': fields.Date.from_string('2020-01-03')},
            ],
            [
                {'date': fields.Date.from_string('2020-01-03')},
                {'date': fields.Date.from_string('2020-01-03')},
            ],
        ]
        for report_line, report_line_dict, expected_values in zip(report.line_ids, report_lines, expected_redirection_values_list):
            with self.subTest(report_line=report_line.name):
                action_dict = report.action_audit_cell(options, self._get_audit_params_from_report_line(options, report_line, report_line_dict))
                self.assertRecordValues(
                    self.env['account.report.external.value'].search(action_dict['domain']),
                    expected_values,
                )

        options = self._generate_options(report, '2020-01-03', '2020-01-05')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',          800.0),
                ('test_line_2',          300.0),
            ],
            options,
        )

    def test_engine_external_editable_percentage(self):
        self.env = self.env(context=dict(self.env.context, allowed_company_ids=self.env.company.ids))

        # Create the report.
        test_rounding_4 = self._prepare_test_report_line(
            self._prepare_test_expression_external(
                'most_recent', [
                    self._prepare_test_external_values(10.1254, '2020-01-01'),
                    self._prepare_test_external_values(5, '2020-01-02'),
                ], figure_type='percentage', subformula='editable;rounding=4',
            ),
            code='TEST_PERCENTAGE'
        )
        test_rounding_2 = self._prepare_test_report_line(
            self._prepare_test_expression_external(
                'most_recent', [
                    self._prepare_test_external_values(10.12, '2020-01-01'),
                    self._prepare_test_external_values(5, '2020-01-02'),
                ], figure_type='percentage', subformula='editable;rounding=2',
            )
        )
        test_percentage_aggregate = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('10000 * TEST_PERCENTAGE.balance'),
        )
        test_float = self._prepare_test_report_line(
            self._prepare_test_expression_external(
                'most_recent', [
                    self._prepare_test_external_values(10.12, '2020-01-01'),
                    self._prepare_test_external_values(5, '2020-01-02'),
                ], figure_type='float', subformula='editable;rounding=2',
            )
        )

        report = self._create_report([test_rounding_4, test_rounding_2, test_percentage_aggregate, test_float])
        # Check the values at multiple dates.
        options = self._generate_options(report, '2020-01-01', '2020-01-01')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [0,                          1],
            [
                ('test_line_1', '10.1254%'),
                ('test_line_2',   '10.12%'),
                ('test_line_3',     101254),
                ('test_line_4',    '10.12'),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-02', '2020-01-02')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [0,                         1],
            [
                ('test_line_1', '5.0000%'),
                ('test_line_2',   '5.00%'),
                ('test_line_3',     50000),
                ('test_line_4',    '5.00'),
            ],
            options,
        )

    def test_engine_reference(self):
        lines_with_old_value = [
            self._prepare_test_report_line(
                self._prepare_test_expression_reference(
                    'res.partner',
                    [self._prepare_test_external_values(f'res.partner:{self.partner_a.id}', '2020-01-01', 'string')],
                    figure_type='many2one',
                    date_scope=date_scope,
                )
            )
            for date_scope in ['from_beginning', 'strict_range']
        ]
        empty_lines = [
            self._prepare_test_report_line(
                self._prepare_test_expression_reference(
                    'res.partner',
                    [
                        self._prepare_test_external_values(f'res.partner:{self.partner_a.id}', '2020-01-01', 'string'),
                        self._prepare_test_external_values('res.partner:0', '2020-01-02', 'string'),
                    ],
                    figure_type='many2one',
                    date_scope=date_scope,
                )
            )
            for date_scope in ['from_beginning', 'strict_range']
        ]
        report = self._create_report(lines_with_old_value + empty_lines)
        options = self._generate_options(report, '2020-01-02', '2020-01-02')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [    0,             1],
            [
                ('test_line_1', self.partner_a.display_name),
                ('test_line_2', ''),
                ('test_line_3', ''),
                ('test_line_4', ''),
            ],
            options,
        )

    def test_engine_custom(self):
        # Create the report.
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_custom('_custom_engine_test', subformula='sum'),
            groupby='account_id', foldability='always_unfolded'
        )
        report = self._create_report([test_line_1])

        # Create the journal entries.
        self._create_test_account_moves([
            self._prepare_test_account_move_line(2000.0, account_code='101001'),
            self._prepare_test_account_move_line(-300.0, account_code='101002'),
        ])

        # Check the values.

        def _custom_engine_test(options, date_scope, formulas_dict, current_groupby, warnings=None):
            domain = [('account_id.code', '=', '101002')]
            domain_key = str(domain)
            domain_formulas_dict = {domain_key: next(iter(formulas_dict.values()))}
            domain_result = report._report_engine_domain(options, date_scope, domain_formulas_dict, current_groupby)
            return {next(iter(formulas_dict.values())): next(iter(domain_result.values()))}

        orig_get_custom_report_function = report._get_custom_report_function

        def get_custom_report_function(_report, function_name, prefix):
            if function_name == '_custom_engine_test':
                return _custom_engine_test
            return orig_get_custom_report_function(function_name, prefix)

        with patch.object(type(report), '_get_custom_report_function', get_custom_report_function):
            options = self._generate_options(report, '2020-01-01', '2020-01-01')
            self.assertLinesValues(
                # pylint: disable=bad-whitespace
                report._get_lines(options),
                [   0,                          1],
                [
                    ('test_line_1',        -300.0),
                    ('101002 101002',      -300.0),
                ],
                options,
            )

    def test_engine_aggregation(self):
        self.env.company.account_fiscal_country_id = self.fake_country

        # Test division by zero.
        test1 = self._prepare_test_report_line(
            self._prepare_test_expression_tax_tags('11', label='tax_tags'),
            self._prepare_test_expression_domain([('account_id.code', '=', '101002')], 'sum', label='domain'),
            self._prepare_test_expression_external('sum', [self._prepare_test_external_values(100.0, '2020-01-01')], label='external'),
            self._prepare_test_expression_aggregation('test1.tax_tags + test1.domain', column='aggregation'),
            self._prepare_test_expression_aggregation('test1.tax_tags / 0', subformula='ignore_zero_division'),
            self._prepare_test_expression_external('sum', [self._prepare_test_external_values(100.47, '2020-01-01')], label='external_decimal'),
            name='test1', code='test1',
        )

        # Test if_(above|below|between) operators.
        test2_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.tax_tags', subformula='if_above(USD(0))'),
            name='test2_1', code='test2_1',
        )
        test2_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.tax_tags', subformula='if_above(USD(1999.9999999))'),
            name='test2_2', code='test2_2',
        )
        test2_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.tax_tags', subformula='if_above(USD(2500.0))'),
            name='test2_3', code='test2_3',
        )
        test2_4 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.tax_tags', subformula='if_above(CAD(3600.0))'),
            name='test2_4', code='test2_4',
        )
        test3_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.domain', subformula='if_below(USD(0))'),
            name='test3_1', code='test3_1',
        )
        test3_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.domain', subformula='if_below(USD(-300.00001))'),
            name='test3_2', code='test3_2',
        )
        test3_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.domain', subformula='if_below(USD(- 350))'),
            name='test3_3', code='test3_3',
        )
        test4_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.tax_tags + test1.domain', subformula='if_between(USD(0), USD(2000))'),
            name='test4_1', code='test4_1',
        )
        test4_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.tax_tags + test1.domain', subformula='if_between(CAD(0), CAD(3000))'),
            name='test4_2', code='test4_2',
        )

        # Test line code recognition.
        test5 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('101003', label='account_codes'),
            self._prepare_test_expression_aggregation('test1.tax_tags + 9999.account_codes'),
            name='9999', code='9999',
        )

        # Test mathematical operators.
        test6 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation(
                '(test1.tax_tags + (2 * test1.domain) + 100.0) / (9999.account_codes)'
            ),
            name='test6', code='test6',
        )

        # Test other date scope
        test7 = self._prepare_test_report_line(
            self._prepare_test_expression_domain(
                [('account_id.code', '=', '101002')],
                'sum',
                label='domain',
                date_scope='to_beginning_of_period',
            ),
            self._prepare_test_expression_aggregation('test7.domain'),
            name='test7', code='test7',
        )

        # Test exponential notation
        test9 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation(
                '(test1.tax_tags + (2 * test1.domain) + 100.0 + 1.752e-17) / (9999.account_codes)'
            ),
            name='test9', code='test9',
        )

        # Test 'round' subformula
        test10_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external_decimal', subformula='round(0)'),
            name='test10_1', code='test10_1',
        )
        test10_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external_decimal', subformula='round(1)'),
            name='test10_2', code='test10_2',
        )
        test10_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external_decimal', subformula='round(3)'),
            name='test10_3', code='test10_3',
        )

        # Test if_other_expr_above / if_other_expr_below
        test11_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external', subformula='if_other_expr_above(test1.tax_tags, USD(3000.0))'),
            name='test11_1', code='test11_1',
        )
        test11_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external', subformula='if_other_expr_below(test1.tax_tags, USD(3000.0))'),
            name='test11_2', code='test11_2',
        )
        test11_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external', subformula='if_other_expr_above(test1.tax_tags, USD(1000.0))'),
            name='test11_3', code='test11_3',
        )
        test11_4 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external', subformula='if_other_expr_below(test1.tax_tags, USD(1000.0))'),
            name='test11_4', code='test11_4',
        )
        # Test with an aggregation in the condition
        test11_5 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external', subformula='if_other_expr_above(test1.aggregation, USD(1000.0))'),
            name='test11_5', code='test11_5',
        )
        test11_6 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.external', subformula='if_other_expr_below(test1.aggregation, USD(1000.0))'),
            name='test11_6', code='test11_6',
        )
        test11_7 = self._prepare_test_report_line(  # Special case: same dependency in the formula and subformula
            self._prepare_test_expression_aggregation('test1.aggregation', subformula='if_other_expr_above(test1.aggregation, USD(1000.0))'),
            name='test11_7', code='test11_7',
        )

        # Test sum_children formula (parent_id relationship is populated below)
        test_12_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('sum_children'),
            name='test12_1', code='test12_1',
        )
        test_12_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.tax_tags'),
            name='test12_2', code='test12_2',
        )
        test_12_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test1.domain'),
            name='test12_3', code='test12_3',
        )
        test_12_4 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('sum_children'),
            name='test12_4', code='test12_4',
        )
        test_12_5 = self._prepare_test_report_line(
            self._prepare_test_expression_domain([('account_id.code', '=', '101003')], 'sum'),
            name='test12_5', # No code on purpose to check a different case of sum_children
        )

        report = self._create_report(
            [
                test1, test2_1, test2_2, test2_3, test2_4, test3_1, test3_2, test3_3, test4_1, test4_2,
                test5, test6, test7, test9, test10_1, test10_2, test10_3, test11_1, test11_2, test11_3, test11_4,
                test11_5, test11_6, test11_7, test_12_1, test_12_2, test_12_3, test_12_4, test_12_5,
            ],
            country_id=self.fake_country.id,
        )

        # Set parent link properly for sum_children test, now that all lines are created:
        line_12_1 = self.env['account.report.line'].search([('code', '=', 'test12_1')])
        self.env['account.report.line'].search([('code', 'in', ('test12_2', 'test12_3', 'test12_4'))]).parent_id = line_12_1
        line_12_4 = self.env['account.report.line'].search([('code', '=', 'test12_4')])
        self.env['account.report.line'].search([('name', '=', 'test12_5')]).parent_id = line_12_4

        # Create the journal entries.
        moves = self._create_test_account_moves([
            self._prepare_test_account_move_line(100000.0, account_code='101002', date='2019-01-01'),
            self._prepare_test_account_move_line(2000.0, account_code='101001', tax_tags=['11']),
            self._prepare_test_account_move_line(-300.0, account_code='101002'),
            self._prepare_test_account_move_line(1500.0, account_code='101003'),
        ])

        # Check the values.
        options = self._generate_options(report, '2020-01-01', '2020-01-01')
        report_lines = report._get_lines(options)
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_lines,
            [   0,                          1],
            [
                ('test1',                 0.0),
                ('test2_1',            2000.0),
                ('test2_2',               0.0),
                ('test2_3',               0.0),
                ('test2_4',            2000.0),
                ('test3_1',            -300.0),
                ('test3_2',               0.0),
                ('test3_3',               0.0),
                ('test4_1',            1700.0),
                ('test4_2',               0.0),
                ('9999',               3500.0),
                ('test6',                 1.0),
                ('test7',            100000.0),
                ('test9',                 1.0),
                ('test10_1',            100.0),
                ('test10_2',            100.5),
                ('test10_3',            100.47),
                ('test11_1',              0.0),
                ('test11_2',            100.0),
                ('test11_3',            100.0),
                ('test11_4',              0.0),
                ('test11_5',            100.0),
                ('test11_6',              0.0),
                ('test11_7',           1700.0),
                ('test12_1',           3200.0),
                ('test12_2',           2000.0),
                ('test12_3',           -300.0),
                ('test12_4',           1500.0),
                ('test12_5',           1500.0),
            ],
            options,
        )

        # Check redirection.
        expected_amls_to_test = [
            ('9999', moves[1].line_ids[0] + moves[1].line_ids[2]),
            ('test7', moves[0].line_ids[0]),
            ('test12_1', moves[1].line_ids[:3]),
        ]
        for report_line_name, expected_amls in expected_amls_to_test:
            report_line = report.line_ids.filtered(lambda x: x.name == report_line_name)
            report_line_dict = next(x for x in report_lines if x.name == report_line.name)
            with self.subTest(report_line=report_line.name):
                action_dict = report.action_audit_cell(options, self._get_audit_params_from_report_line(options, report_line, report_line_dict))
                self.assertEqual(moves.line_ids.filtered_domain(action_dict['domain']), expected_amls)

    def test_engine_aggregation_cross_report(self):
        moves = self._create_test_account_moves([
            self._prepare_test_account_move_line(10.0, account_code='100000', date='2020-01-01'),
            self._prepare_test_account_move_line(5.0, account_code='200000', date='2020-01-01'),
            self._prepare_test_account_move_line(2.0, account_code='100000', date='2021-01-01'),
            self._prepare_test_account_move_line(4.0, account_code='200000', date='2021-01-01'),
        ])

        # First sub report
        report0_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1'),
            name='report0_line_1', code='report0_line_1',
        )
        report0_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('2'),
            name='report0_line_2', code='report0_line_2',
        )
        report0_line_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report0_line_1.balance + report0_line_2.balance'),
            name='report_line_3', code='report_line_3',
        )
        report0 = self._create_report([report0_line_1, report0_line_2, report0_line_3])
        report0_options = self._generate_options(report0, '2021-01-01', '2021-01-01')

        # Second sub report
        report1_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1'),
            name='report1_line_1', code='report1_line_1',
        )
        report1_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('2'),
            name='report1_line_2', code='report1_line_2',
        )
        report1_line_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report1_line_1.balance - report1_line_2.balance'),
            name='report_line_3', code='report_line_3',
        )

        report1 = self._create_report([report1_line_1, report1_line_2, report1_line_3])
        report1_options = self._generate_options(report1, '2021-01-01', '2021-01-01')

        # report_line_3 is made ambiguous on purpose to check that we can target the right report using cross_report aggregation
        # First target the first other report using the xmlID
        self.env['ir.model.data']._update_xmlids([
            {
                'xml_id': "account_reports.test_report_cross_report_0",
                'record': report0
            }
        ])
        main_report_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_line_3.balance', subformula='cross_report(account_reports.test_report_cross_report_0)'),
            name='main_report_line', code='main_report_line',
        )
        main_report_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_line_3.balance', subformula='cross_report(account_reports.test_report_cross_report_0, force_date_scope)', date_scope='from_beginning'),
            name='main_report_line_from_beginning', code='main_report_line_from_beginning',
        )
        main_report_line_total = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('main_report_line.balance + main_report_line_from_beginning.balance'),
            name='main_report_line_total', code='main_report_line_total',
        )
        main_report = self._create_report([main_report_line_1, main_report_line_2, main_report_line_total])
        main_report_options = self._generate_options(main_report, '2021-01-01', '2021-01-01')

        self.assertLinesValues(
            report0._get_lines(report0_options),
            [   0,                                  1],
            [
                ('report0_line_1',                  2.0),
                ('report0_line_2',                  4.0),
                ('report_line_3',                   6.0),
            ],
            report0_options,
        )

        self.assertLinesValues(
            main_report._get_lines(main_report_options),
            [   0,                                      1],
            [
                ('main_report_line',                    6.0),
                ('main_report_line_from_beginning',    21.0),
                ('main_report_line_total',             27.0),
            ],
            main_report_options,
        )

        # Target the second other report using the model id
        main_report_line_1 = self._prepare_test_report_line(
            # Use a different date_scope here to ensure it does not get forced and has no effect
            self._prepare_test_expression_aggregation('report_line_3.balance', subformula=f'cross_report({report1.id})', date_scope='from_beginning'),
            name='main_report_line', code='main_report_line',
        )
        main_report_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_line_3.balance', subformula=f'cross_report({report1.id}, force_date_scope)', date_scope='from_beginning'),
            name='main_report_line_from_beginning', code='main_report_line_from_beginning',
        )
        main_report_line_total = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('main_report_line.balance + main_report_line_from_beginning.balance'),
            name='main_report_line_total', code='main_report_line_total',
        )
        main_report = self._create_report([main_report_line_1, main_report_line_2, main_report_line_total])
        main_report_options = self._generate_options(main_report, '2021-01-01', '2021-01-01')

        self.assertLinesValues(
            report1._get_lines(report1_options),
            [   0,                                      1],
            [
                ('report1_line_1',                      2.0),
                ('report1_line_2',                      4.0),
                ('report_line_3',                      -2.0),
            ],
            report1_options,
        )
        main_report_lines = main_report._get_lines(main_report_options)
        self.assertLinesValues(
            main_report_lines,
            [   0,                                      1],
            [
                ('main_report_line',                   -2.0),
                ('main_report_line_from_beginning',     3.0),
                ('main_report_line_total',              1.0),
            ],
            main_report_options,
        )

        expected_amls_to_test = [
            ('main_report_line', moves[1].line_ids[0:2]),
            ('main_report_line_from_beginning', moves[0].line_ids[0:2] + moves[1].line_ids[0:2]),
        ]

        for report_line_name, expected_amls in expected_amls_to_test:
            report_line = main_report.line_ids.filtered(lambda x: x.name == report_line_name)
            report_line_dict = next(x for x in main_report_lines if x.name == report_line.name)
            with self.subTest(report_line=report_line.name):
                action_dict = main_report.action_audit_cell(main_report_options, self._get_audit_params_from_report_line(main_report_options, report_line, report_line_dict))
                self.assertEqual(moves.line_ids.filtered_domain(action_dict['domain']), expected_amls)

    def test_engine_aggregation_cross_report_triangle(self):
        self._create_test_account_moves([
            self._prepare_test_account_move_line(42.0, account_code='100000', date='2019-04-07'),
            self._prepare_test_account_move_line(11.0, account_code='100000', date='2020-01-01'),
        ])

        report_1_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_2_line_3.balance', subformula='cross_report(account_reports.test_report_cross_report_2)'),
            name='report_1_line_1', code='report_1_line_1',
        )

        report_2_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1'),
            name='report_2_line_1', code='report_2_line_1',
        )
        report_2_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_1_line_1.balance', subformula='cross_report(account_reports.test_report_cross_report_1)'),
            name='report_2_line_2', code='report_2_line_2',
        )
        report_2_line_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_2_line_1.balance + 13'),
            name='report_2_line_3', code='report_2_line_3',
        )

        report_1 = self._create_report([report_1_line_1])
        report_2 = self._create_report([report_2_line_1, report_2_line_2, report_2_line_3])

        self.env['ir.model.data']._update_xmlids([
            {
                'xml_id': "account_reports.test_report_cross_report_1",
                'record': report_1,
            },
            {
                'xml_id': "account_reports.test_report_cross_report_2",
                'record': report_2,
            }
        ])

        options = self._generate_options(report_2, '2020-01-01', '2020-01-01')

        self.assertLinesValues(
            report_2._get_lines(options),
            [   0,                                  1],
            [
                ('report_2_line_1',                 11.0),
                ('report_2_line_2',                 24.0),
                ('report_2_line_3',                 24.0),
            ],
            options,
        )

    def test_engine_aggregation_cross_report_clashing_codes(self):
        self._create_test_account_moves([
            self._prepare_test_account_move_line(11.0, account_code='100000', date='2020-01-01'),
        ])

        report_1_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1'),
            name='report_1_line_1', code='dudu',
        )
        report_1_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('dudu.balance'),
            name='report_1_line_2', code='report_1_line_2',
        )
        report_1 = self._create_report([report_1_line_1, report_1_line_2])

        report_2_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_1_line_2.balance', subformula=f'cross_report({report_1.id})'),
            name='report_2_line_1', code='dudu',
        )
        report_2 = self._create_report([report_2_line_1])

        options = self._generate_options(report_2, '2020-01-01', '2020-01-01')
        self.assertLinesValues(
            report_2._get_lines(options),
            [   0,                                  1],
            [
                ('report_2_line_1',                 11.0),
            ],
            options,
        )

    def test_engine_aggregation_cross_report_referencing_local(self):
        """ Tests the case where a cross-report aggregation also references an expression of its report.
        """
        self._create_test_account_moves([
            self._prepare_test_account_move_line(11.0, account_code='100000', date='2020-01-01'),
            self._prepare_test_account_move_line(42.0, account_code='200000', date='2020-01-01'),
        ])

        report_1_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1'),
            name='report_1_line_1', code='report_1_line_1',
        )
        report_1 = self._create_report([report_1_line_1])

        report_2_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('report_1_line_1.balance + report_2_line_2.balance', subformula=f'cross_report({report_1.id})'),
            name='report_2_line_1', code='report_2_line_1',
        )
        report_2_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('2'),
            name='report_2_line_2', code='report_2_line_2',
        )
        report_2 = self._create_report([report_2_line_1, report_2_line_2])

        options = self._generate_options(report_2, '2020-01-01', '2020-01-01')
        self.assertLinesValues(
            report_2._get_lines(options),
            [   0,                                  1],
            [
                ('report_2_line_1',                 53.0),
                ('report_2_line_2',                 42.0),
            ],
            options,
        )

    def test_engine_aggregation_expansion(self):
        report = self._create_report([
            self._prepare_test_report_line(
                self._prepare_test_expression_tax_tags('42'),
                code='TAG_1',
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_tax_tags('221292'),
                code='TAG_2',
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_tax_tags('777'),
                code='TAG_3',
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('TAG_1.balance + TAG_2.balance'),
                code='SIMPLE_AGG',
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('SIMPLE_AGG.balance + TAG_3.balance'),
                code='COMPLEX_AGG',
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('TAG_1.balance + TAG_2.balance', subformula='if_other_expr_above(TAG_3.balance, EUR(13))'),
                code='BOUNDED_AGG',
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_tax_tags('3333'),
            ),
        ])

        other_report = self._create_report([
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('SIMPLE_AGG.balance + BOUNDED_AGG.balance', subformula=f'cross_report({report.id})'),
                code='CROSS_REPORT_AGG',
            ),
        ])

        expr_map = {expression.report_line_id.code: expression for expression in (report + other_report).line_ids.expression_ids}

        self.assertEqual(
            expr_map['SIMPLE_AGG']._expand_aggregations(),
            expr_map['SIMPLE_AGG'] + expr_map['TAG_1'] + expr_map['TAG_2'],
        )

        self.assertEqual(
            expr_map['COMPLEX_AGG']._expand_aggregations(),
            expr_map['COMPLEX_AGG'] + expr_map['SIMPLE_AGG'] + expr_map['TAG_1'] + expr_map['TAG_2'] + expr_map['TAG_3'],
        )

        self.assertEqual(
            expr_map['BOUNDED_AGG']._expand_aggregations(),
            expr_map['BOUNDED_AGG'] + expr_map['TAG_1'] + expr_map['TAG_2'] + expr_map['TAG_3'],
        )

        self.assertEqual(
            expr_map['CROSS_REPORT_AGG']._expand_aggregations(),
            expr_map['CROSS_REPORT_AGG'] + expr_map['SIMPLE_AGG'] + expr_map['BOUNDED_AGG'] + expr_map['TAG_1'] + expr_map['TAG_2'] + expr_map['TAG_3'],
        )

    def test_engine_aggregation_groupby(self):

        partner_a, partner_b, partner_c = self.env['res.partner'].create([
            {'name': 'Partner A'},
            {'name': 'Partner B'},
            {'name': 'Partner C'},
        ])

        self._create_test_account_moves([
            self._prepare_test_account_move_line(100.0, partner_id=partner_a.id, account_code='100000', date='2020-01-01'),
            self._prepare_test_account_move_line(200.0, partner_id=partner_b.id, account_code='100000', date='2020-01-01'),
            self._prepare_test_account_move_line(300.0, partner_id=partner_c.id, account_code='100000', date='2020-01-01'),
            self._prepare_test_account_move_line(10.0, partner_id=partner_a.id, account_code='200000', date='2020-01-01'),
            self._prepare_test_account_move_line(20.0, partner_id=partner_b.id, account_code='200000', date='2020-01-01'),

            self._prepare_test_account_move_line(150.0, partner_id=partner_a.id, account_code='100000', date='2019-01-01'),
        ])

        report_1 = self._create_report([
            # 1. Account code expressions
            self._prepare_test_report_line(
                self._prepare_test_expression_account_codes('1'),
                name='account_code_1', code='account_code_1', foldability='always_unfolded'
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_account_codes('2'),
                name='account_code_2', code='account_code_2', foldability='always_unfolded'
            ),
            # 2. Aggregation expression groupby (account_code_1 * 2 + account_code_2)
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('account_code_1.balance * 2 + account_code_2.balance'),
                name='agg_groupby', code='agg_groupby', foldability='always_unfolded',
            ),
            # 3. Zero division fallback
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('account_code_1.balance / 0', subformula='ignore_zero_division'),
                name='zero_div_groupby', code='zero_div_groupby', foldability='always_unfolded',
            ),
            # 4. Bounds if_above
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('agg_groupby.balance', subformula='if_above(USD(1000.0))'),
                name='if_above_groupby', code='if_above_groupby', foldability='always_unfolded',
            ),
            # 5. Bounds if_below
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('agg_groupby.balance', subformula='if_below(USD(1000.0))'),
                name='if_below_groupby', code='if_below_groupby', foldability='always_unfolded',
            ),
            # 6. Bounds if_other_expr_above (total of account_code_2 > 20)
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('agg_groupby.balance', subformula='if_other_expr_above(account_code_2.balance, USD(20.0))'),
                name='if_other_expr_above_groupby', code='if_other_expr_above_groupby', foldability='always_unfolded',
            ),
            # 7. Bounds if_other_expr_below (total of account_code_2 < 20)
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('agg_groupby.balance', subformula='if_other_expr_below(account_code_2.balance, USD(20.0))'),
                name='if_other_expr_below_groupby', code='if_other_expr_below_groupby', foldability='always_unfolded',
            ),
        ],
        groupby='partner_id',
        )

        options_1 = self._generate_options(report_1, '2020-01-01', '2020-01-01')
        lines_1 = report_1._get_lines(options_1)

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            lines_1,
            [   0,                                  1],
            [
                # account_code_1 (partner a: 100, b: 200, c: 300) total 600
                ('account_code_1',              600.0),
                ('Partner A',                   100.0),
                ('Partner B',                   200.0),
                ('Partner C',                   300.0),

                # account_code_2 (account 200000: a: 10, b: 20) total 30
                ('account_code_2',               30.0),
                ('Partner A',                    10.0),
                ('Partner B',                    20.0),

                # agg_groupby (account_code_1 * 2 + account_code_2)
                # : (a: 100*2 + 10 = 210, b: 200*2 + 20 = 420, c: 300*2 + 0 = 600) total 1230
                ('agg_groupby',                1230.0),
                ('Partner A',                   210.0),
                ('Partner B',                   420.0),
                ('Partner C',                   600.0),

                # zero_div_groupby (ignore returns 0)
                ('zero_div_groupby',              0.0),
                ('Partner A',                     0.0),
                ('Partner B',                     0.0),
                ('Partner C',                     0.0),

                # if_above_groupby (agg_groupby if total > 1000 => 1230 > 1000 is True)
                ('if_above_groupby',           1230.0),
                ('Partner A',                   210.0),
                ('Partner B',                   420.0),
                ('Partner C',                   600.0),

                # if_below_groupby (agg_groupby if total < 1000 => 1230 < 1000 is False, so 0)
                ('if_below_groupby',              0.0),

                # if_other_expr_above_groupby (agg_groupby if account_code_2 > 20 => 30 > 20 is True)
                ('if_other_expr_above_groupby', 1230.0),
                ('Partner A',                   210.0),
                ('Partner B',                   420.0),
                ('Partner C',                   600.0),

                # if_other_expr_below_groupby (agg_groupby if account_code_2 < 20 => 30 < 20 is False, so 0)
                ('if_other_expr_below_groupby',   0.0),
            ],
            options_1,
        )

        ####################
        # Report 2
        ####################

        report_2 = self._create_report([
            # 1. Simple cross_report expression groupby
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('agg_groupby.balance', subformula=f'cross_report({report_1.id})'),
                name='cross_report_groupby', code='cross_report_groupby', foldability='always_unfolded',
            ),
            # 2. cross_report expression groupby with force_date_scope
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('agg_groupby.balance', subformula=f'cross_report({report_1.id}, force_date_scope)', date_scope='from_beginning'),
                name='cross_report_forced_groupby', code='cross_report_forced_groupby', foldability='always_unfolded',
            ),
            self._prepare_test_report_line(
                self._prepare_test_expression_account_codes('2'),
                name='account_code_2', code='account_code_2', foldability='always_unfolded'
            ),
            # 3. Aggregation expanding to a cross report expression groupby
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('cross_report_groupby.balance * 1.5 + account_code_2.balance'),
                name='agg_expand_cross_groupby', code='agg_expand_cross_groupby', foldability='always_unfolded',
            ),
            # 4. Mix of all cases
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('cross_report_forced_groupby.balance + agg_expand_cross_groupby.balance + 10'),
                name='mix_all_groupby', code='mix_all_groupby', foldability='always_unfolded'
            ),
        ],
        groupby='partner_id',
        )

        options_2 = self._generate_options(report_2, '2020-01-01', '2020-01-01')
        lines_2 = report_2._get_lines(options_2)

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            lines_2,
            [   0,                                  1],
            [
                # cross_report_groupby (references agg_groupby: a: 200, b: 400, c: 600)
                ('cross_report_groupby',       1230.0),
                ('Partner A',                   210.0),
                ('Partner B',                   420.0),
                ('Partner C',                   600.0),

                # cross_report_forced_groupby (references agg_groupby with date_scope='from_beginning')
                ('cross_report_forced_groupby', 1530.0),
                ('Partner A',                   510.0),  # a: (150(from 2019) + 100(from 2020)) * 2 + 10(from 2020) = 510
                ('Partner B',                   420.0),  # b: 200 * 2 + 20 = 420
                ('Partner C',                   600.0),  # c: 300 * 2 + 0 = 600

                ('account_code_2',              30.0),
                ('Partner A',                   10.0),
                ('Partner B',                   20.0),

                # agg_expand_cross_groupby (cross_report_groupby * 1.5 + account_code_2)
                # a: 210*1.5+10= 325, b: 420*1.5+20= 650, c: 600*1.5+0= 900
                ('agg_expand_cross_groupby',   1875.0),
                ('Partner A',                   325.0),
                ('Partner B',                   650.0),
                ('Partner C',                   900.0),

                # mix_all_groupby (cross_report_forced_groupby.balance + agg_expand_cross_groupby.balance + 10)
                ('mix_all_groupby',            3415.0),
                ('Partner A',                   845.0),  # a: 510 + 325 + 10 = 845
                ('Partner B',                  1080.0),  # b: 420 + 650 + 10 = 1080
                ('Partner C',                  1510.0),  # c: 600 + 900 + 10 = 1510
            ],
            options_2,
        )

    def test_load_more(self):
        self.env = self.env(context={'allowed_company_ids': self.env.company.ids})

        partner_a, partner_b, partner_c = self.env['res.partner'].create([
            {'name': 'Partner A'},
            {'name': 'Partner B'},
            {'name': 'Partner C'},
        ])

        self._create_test_account_moves([
            self._prepare_test_account_move_line(1000.0, partner_id=partner_a.id, date='2020-01-01'),
            self._prepare_test_account_move_line(2000.0, partner_id=partner_b.id, date='2020-01-01'),
            self._prepare_test_account_move_line(3000.0, partner_id=partner_c.id, date='2020-01-01'),
        ])

        report = self._create_report(
            test_report_line_values_list=[self._prepare_test_report_line(
                self._prepare_test_expression_domain([('partner_id', '!=', False)], 'sum'),
                groupby='partner_id',
                foldability='always_unfolded',
            )],
            load_more_limit=2,
        )

        options = self._generate_options(report, '2020-01-01', '2020-01-31')
        lines = report._get_lines(options)

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            lines,
            [   0,                                1],
            [
                ('test_line_1',             6000.00),
                ('Partner A',               1000.00),
                ('Partner B',               2000.00),
                ('1 more',                  3000.00),
            ],
            options,
        )

        load_more_line = lines[-1]
        load_more_res = report.get_expanded_lines(
            options,
            load_more_line.id,
            load_more_line.groupby,
            load_more_line.expand_function,
            None,
            None,
            ignore_load_more=True,
        )

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            load_more_res,
            [   0,                                1],
            [
                ('Partner A',               1000.00),
                ('Partner B',               2000.00),
                ('Partner C',               3000.00),
            ],
            options,
        )

    def test_engine_external_boolean(self):
        # Create the report.
        test_line = self._prepare_test_report_line(
            self._prepare_test_expression_external('most_recent', [
                self._prepare_test_external_values('1', '2020-01-02'),
                self._prepare_test_external_values('0', '2020-01-03'),
                self._prepare_test_external_values('1', '2020-01-03'),
                self._prepare_test_external_values('0', '2020-01-05'),
            ], figure_type='boolean')
        )

        report = self._create_report([test_line])
        # Check the values at multiple dates.
        options = self._generate_options(report, '2020-01-01', '2020-01-01')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',          'No'),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-02', '2020-01-02')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',         'Yes'),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-03', '2020-01-03')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',         'Yes'),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-05', '2020-01-05')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',          'No'),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-02', '2020-01-05')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1],
            [
                ('test_line_1',          'No'),
            ],
            options,
        )

    def test_engine_external_string(self):
        # Create the report.
        test_line = self._prepare_test_report_line(
            self._prepare_test_expression_external('most_recent', [
                self._prepare_test_external_values('TARDIS', '2020-01-02', figure_type='string'),
                self._prepare_test_external_values('Kris Kelvin', '2020-01-03', figure_type='string'),
                self._prepare_test_external_values('Trisolaris', '2020-01-03', figure_type='string'),
                self._prepare_test_external_values("5-ounce bird carrying a 1-pound coconut", '2020-01-05', figure_type='string'),
            ], figure_type='string')
        )

        report = self._create_report([test_line])
        # Check the values at multiple dates.
        options = self._generate_options(report, '2020-01-01', '2020-01-01')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                                    1],
            [
                ('test_line_1',                      ''),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-02', '2020-01-02')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                                    1],
            [
                ('test_line_1',                'TARDIS'),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-03', '2020-01-03')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                                    1],
            [
                ('test_line_1',            'Trisolaris'),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-05', '2020-01-05')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                                    1],
            [
                ('test_line_1', "5-ounce bird carrying a 1-pound coconut"),
            ],
            options,
        )

        options = self._generate_options(report, '2020-01-02', '2020-01-05')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                                    1],
            [
                ('test_line_1', "5-ounce bird carrying a 1-pound coconut"),
            ],
            options,
        )

    def test_engine_external_default_value_tax_closing_fiscalyear_lock_date(self):
        def lock_via_fiscalyear_lock_date(non_tax_report, tax_report, report_options_map):
            lock_date_wizard = self.env['account.change.lock.date'].create({
                'fiscalyear_lock_date': fields.Date.from_string('2020-01-02'),
            })
            lock_date_wizard.change_lock_date()

        self._run_external_engine_default_test_case(False, True, lock_via_fiscalyear_lock_date)

    def test_engine_external_default_value_tax_closing_tax_lock_date(self):
        def lock_via_tax_lock_date(non_tax_report, tax_report, report_options_map):
            lock_date_wizard = self.env['account.change.lock.date'].create({
                'tax_lock_date': fields.Date.from_string('2020-01-02'),
            })
            lock_date_wizard.change_lock_date()

        self._run_external_engine_default_test_case(True, False, lock_via_tax_lock_date)

    def test_engine_external_default_value_tax_closing(self):
        def lock_via_tax_closing(non_tax_report, tax_report, report_options_map):
            return_type = self.env['account.return.type'].create({
                'name': "Bat-report",
                'report_id': tax_report.id,
                'tax_payable_account_id': self.company_data['default_tax_account_payable'].id,
                'tax_receivable_account_id': self.company_data['default_tax_account_receivable'].id,
            })
            tax_return = self.env['account.return'].create({
                'name': "Bat-return",
                'company_id': self.env.company.id,
                'type_id': return_type.id,
                'date_from': report_options_map[tax_report]['date']['date_from'],
                'date_to': report_options_map[tax_report]['date']['date_to'],
            })

            with self.allow_pdf_render():
                tax_return.action_submit()

        self._run_external_engine_default_test_case(True, False, lock_via_tax_closing)

    def _run_external_engine_default_test_case(self, impact_tax_report, impact_non_tax_report, lock_operation_function):
        """ Common helper to run the tests of _default expressions
        """
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('10'),
            groupby='account_id',
        )
        test_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_external('sum', {}),
            self._prepare_test_expression_account_codes('10', label='_default_balance'),
        )

        non_tax_report = self._create_report([test_line_1, test_line_2], name="non_tax_report")
        tax_report = self._create_report(
            [test_line_1, test_line_2],
            root_report_id=self.env.ref('account.generic_tax_report').id,
            name="tax_report",
            country_id=self.env.ref('base.us').id,
        )

        # Create the journal entries.
        self._create_test_account_moves([
            self._prepare_test_account_move_line(1000.0, account_code='100001'),
            self._prepare_test_account_move_line(-300.0, account_code='101002'),
            self._prepare_test_account_move_line(-600.0, account_code='314159'),
        ])

        report_options_map = {
            report: self._generate_options(
                report,
                '2020-01-01', '2020-01-31',
                default_options={
                    'unfold_all': True,
                }
            )
            for report in [non_tax_report, tax_report]
        }

        # Check the values before locking
        for report in [non_tax_report, tax_report]:
            with self.subTest(report=report.name):
                options = report_options_map[report]
                self.assertLinesValues(
                    # pylint: disable=bad-whitespace
                    report._get_lines(options),
                    [0,                             1],
                    [
                        ('test_line_1',         700.0),
                        ('100001 100001',      1000.0),
                        ('101002 101002',      -300.0),
                        ('test_line_2',           0.0),
                    ],
                    options,
                )

        # Run the lock operation
        lock_operation_function(non_tax_report, tax_report, report_options_map)

        # Check the values after locking
        for report, impacted in [(non_tax_report, impact_non_tax_report), (tax_report, impact_tax_report)]:
            with self.subTest(report=report.name):
                options = report_options_map[report]
                if impacted:
                    self.assertLinesValues(
                        # pylint: disable=bad-whitespace
                        report._get_lines(options),
                        [0,                             1],
                        [
                            ('test_line_1',         700.0),
                            ('100001 100001',      1000.0),
                            ('101002 101002',      -300.0),
                            ('test_line_2',         700.0),
                        ],
                        options,
                    )
                else:
                    self.assertLinesValues(
                        # pylint: disable=bad-whitespace
                        report._get_lines(options),
                        [0,                             1],
                        [
                            ('test_line_1',         700.0),
                            ('100001 100001',      1000.0),
                            ('101002 101002',      -300.0),
                            ('test_line_2',           0.0),
                        ],
                        options,
                    )

    def test_engine_aggregation_cross_bound(self):
        other_report = self._create_report([
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('14.0', subformula='if_other_expr_above(line_2_1.dudu, EUR(0))'),
                self._prepare_test_expression_account_codes('101', label='dudu'),
                name='Line 2-1',
                code='line_2_1',
            ),
        ])

        report_1 = self._create_report([
            self._prepare_test_report_line(
                self._prepare_test_expression_aggregation('line_2_1.balance', subformula=f'cross_report({other_report.id})'),
                name='Line 1-1',
                code='line_1_1',
            ),
        ])

        options = self._generate_options(report_1, '2020-01-01', '2020-01-01')

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_1._get_lines(options),
            [   0,                          1],
            [
                ('Line 1-1',              0.0),
            ],
            options
        )

        self._create_test_account_moves([
            self._prepare_test_account_move_line(10, account_code='101001'),
            self._prepare_test_account_move_line(-10, account_code='100001'),
        ])

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_1._get_lines(options),
            [   0,                          1],
            [
                ('Line 1-1',             14.0),
            ],
            options
        )

    def test_change_expression_engine_to_tax_tags(self):
        """
        Ensure that tax tags are created when switching the expression engine to tax tags if formula is unchanged.
        """
        formula = 'dudu'
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_external(formula, [self._prepare_test_external_values(100.0, '2020-01-01')], label='external'),
        )
        report = self._create_report([test_line_1], country_id=self.fake_country.id)
        tags = self.env['account.account.tag']._get_tax_tags(formula, self.fake_country.id)
        self.assertEqual(len(tags), 0)
        report.line_ids[0].expression_ids[0].engine = 'tax_tags'
        tags = self.env['account.account.tag']._get_tax_tags(formula, self.fake_country.id)
        self.assertEqual(tags.mapped('name'), [formula])

    def test_integer_rounding(self):
        line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_domain([('account_id.code', '=', '101001')], 'sum'),
            code='test_1',
        )
        line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_tax_tags('42'),
            code='test_2',
        )
        line_3 = self._prepare_test_report_line(
            self._prepare_test_expression_account_codes('1'),
            code='test_3',
        )
        line_4 = self._prepare_test_report_line(
            self._prepare_test_expression_external('sum', [
                self._prepare_test_external_values(3.5, '2023-01-01'),
            ]),
            code='test_4',
        )
        line_5 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.balance + test_2.balance + test_3.balance + test_4.balance'),
            code='test_5',
        )
        line_6 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_5.balance / 10'),
        )

        report = self._create_report([line_1, line_2, line_3, line_4, line_5, line_6], country_id=self.fake_country.id,)

        self._create_test_account_moves([
            self._prepare_test_account_move_line(5.4, account_code='101001', tax_tags=['42'], date='2023-01-01'),
        ])

        # Test with a first rounding
        report.integer_rounding = 'HALF-UP'
        half_up_options = self._generate_options(report, '2023-01-01', '2023-01-01')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(half_up_options),
            [   0,                              1],
            [
                ('test_line_1',               5.0),
                ('test_line_2',               5.0),
                ('test_line_3',               5.0),
                ('test_line_4',               4.0),
                ('test_line_5',              19.0),
                ('test_line_6',               2.0),
            ],
            half_up_options,
        )

        # Test with another rounding method
        report.integer_rounding = 'UP'
        up_options = self._generate_options(report, '2023-01-01', '2023-01-01')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(up_options),
            [   0,                              1],
            [
                ('test_line_1',               6.0),
                ('test_line_2',               6.0),
                ('test_line_3',               6.0),
                ('test_line_4',               4.0),
                ('test_line_5',              22.0),
                ('test_line_6',               3.0),
            ],
            up_options
        )

        # In file export mode, the rounding should always be applied, even if it was previously disabled
        print_mode_options = self._generate_options(report, '2023-01-01', '2023-01-01', default_options={'integer_rounding_enabled': False, 'export_mode': 'file'})
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(print_mode_options),
            [   0,                              1],
            [
                ('test_line_1',               6.0),
                ('test_line_2',               6.0),
                ('test_line_3',               6.0),
                ('test_line_4',               4.0),
                ('test_line_5',              22.0),
                ('test_line_6',               3.0),
            ],
            print_mode_options,
        )

        # Rounding available, but disabled
        no_rounding_options = self._generate_options(report, '2023-01-01', '2023-01-01', default_options={'integer_rounding_enabled': False})
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(no_rounding_options),
            [   0,                               1],
            [
                ('test_line_1',               5.40),
                ('test_line_2',               5.40),
                ('test_line_3',               5.40),
                ('test_line_4',               3.50),
                ('test_line_5',              19.70),
                ('test_line_6',               1.97),
            ],
            no_rounding_options,
        )

    def test_print_hide_0_lines(self):
        # Create the report.
        test_line_1 = self._prepare_test_report_line(
            self._prepare_test_expression_tax_tags('11'),
            groupby='account_id',
        )
        test_line_2 = self._prepare_test_report_line(
            self._prepare_test_expression_tax_tags('-222T'),
            groupby='account_id',
        )
        report = self._create_report([test_line_1, test_line_2], country_id=self.fake_country.id)

        # Create the journal entries.
        self._create_test_account_moves([
            self._prepare_test_account_move_line(3000.0, account_code='101001', tax_tags=['11', '222T']),
            self._prepare_test_account_move_line(-3600.0, account_code='101001', tax_tags=['222T']),
            self._prepare_test_account_move_line(600.0, account_code='101001', tax_tags=['222T', '11']),
        ])

        # To ensure that the lines are shown when hide_0_lines isn't toggled and vice versa, we test both scenarios.
        options_not_hide = self._generate_options(
            report,
            '2020-01-01', '2020-01-01',
            default_options={'unfold_all': True, 'export_mode': 'print'}
        )
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options_not_hide),
            [   0,                        1],
            [
                ('test_line_1',      3600.0),
                ('101001 101001',    3600.0),
                ('test_line_2',         0.0),
                ('101001 101001',       0.0),
            ],
            options_not_hide,
        )

        options_hide = self._generate_options(
            report,
            '2020-01-01', '2020-01-01',
            default_options={'unfold_all': True, 'export_mode': 'print', 'hide_0_lines': True}
        )
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options_hide),
            [   0,                        1],
            [
                ('test_line_1',      3600.0),
                ('101001 101001',    3600.0),
            ],
            options_hide,
        )

    def test_column_blank_if_zero(self):
        """account.report.column's `blank_if_zero` option should only impacts number figure types"""
        test_line = self._prepare_test_report_line(
            self._prepare_test_expression_external('most_recent', [], label='monetary', figure_type='monetary'),

            self._prepare_test_expression_external('most_recent', [], label='percentage', figure_type='percentage'),

            self._prepare_test_expression_external('most_recent', [], label='integer', figure_type='integer'),

            self._prepare_test_expression_external('most_recent', [], label='float', figure_type='float'),

            self._prepare_test_expression_external('most_recent', [
                self._prepare_test_external_values(False, '2024-01-01', figure_type='boolean'),
            ], label='boolean', figure_type='boolean'),

            self._prepare_test_expression_external('most_recent', [
                self._prepare_test_external_values('dudu', '2024-01-01', figure_type='string'),
            ], label='string', figure_type='string'),
        )

        report = self._create_report([test_line], columns=['monetary', 'percentage', 'integer', 'float', 'boolean', 'string'])
        report.column_ids.blank_if_zero = True

        options = self._generate_options(report, '2024-01-01', '2024-01-01')
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                          1,  2,   3,  4,      5,       6],
            [
                ('test_line_1',            '', '',  '', '',   'No',  'dudu'),
            ],
            options,
        )

    def test_column_groups_audit(self):
        account = self.company_data['default_account_assets']
        move = self.env['account.move'].create({
            'move_type': 'entry',
            'date': '2024-01-01',
            'line_ids': [
                (0, 0, {'debit': 10.0,      'credit': 0.0,      'account_id': account.id,   'partner_id': self.partner_a.id}),
                (0, 0, {'debit': 20.0,      'credit': 0.0,      'account_id': account.id,   'partner_id': self.partner_b.id}),
                (0, 0, {'debit':  0.0,     'credit': 30.0,      'account_id': account.id}),
            ],
        })
        move.action_post()

        report = self._create_report([
            self._prepare_test_report_line(
                self._prepare_test_expression_domain([('account_id', '=', account.id)], 'sum'),
                code='report_line',
            ),
        ], country_id=self.fake_country.id)

        horizontal_group = self.env['account.report.horizontal.group'].create({
            'name': 'Horizontal Group',
            'report_ids': report.ids,
            'rule_ids': [
                Command.create({
                    'field_name': 'partner_id',
                    'domain': f"[('id', 'in', {(self.partner_a + self.partner_b).ids})]",
                }),
            ],
        })

        main_options = self._generate_options(report, '2024-01-01', '2024-01-01', default_options={'selected_horizontal_group_id': horizontal_group.id})
        lines = report._get_lines(main_options)
        for (col_group_index, col_group_options), expected_partner in zip(report._split_options_per_column_group(main_options).items(), [self.partner_a, self.partner_b]):
            audit_params = self._get_audit_params_from_report_line(col_group_options, report.line_ids, lines[0], column_group_index=col_group_index)
            action_dict = report.action_audit_cell(col_group_options, audit_params)

            expected_amls = move.line_ids.filtered(lambda x: x.partner_id == expected_partner)
            audit_result_amls = move.line_ids.filtered_domain(action_dict['domain'])
            self.assertEqual(audit_result_amls, expected_amls, f"Wrong audit result for partner {expected_partner.name}: {audit_result_amls}")

    def test_account_codes_load_more_limit_groupby(self):
        """ The account_codes engine performs an additional groupby in its SQL query. This tests makes sure this does not break the behavior
        of the load_more_limit when grouping.
        """
        partner_a, partner_b, partner_c = self.env['res.partner'].create([
            {'name': 'Partner A'},
            {'name': 'Partner B'},
            {'name': 'Partner C'},
        ])

        report = self._create_report(
            [
                self._prepare_test_report_line(
                    self._prepare_test_expression_account_codes('1'),
                    groupby='partner_id',
                ),
            ],
            load_more_limit=2,
        )

        move = self._create_test_account_moves([
            self._prepare_test_account_move_line(10, account_code='11', partner_id=partner_a.id),
            self._prepare_test_account_move_line(20, account_code='11', partner_id=partner_a.id),
            self._prepare_test_account_move_line(25, account_code='12', partner_id=partner_a.id),
            self._prepare_test_account_move_line(30, account_code='11'),
            self._prepare_test_account_move_line(40, account_code='11'),
            self._prepare_test_account_move_line(50, account_code='12', partner_id=partner_b.id),
            self._prepare_test_account_move_line(60, account_code='13', partner_id=partner_c.id),
            self._prepare_test_account_move_line(-210, account_code='2'),
        ])

        options = self._generate_options(report, '2020-01-01', '2020-01-01', default_options={'unfold_all': True})

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report._get_lines(options),
            [   0,                               1],
            [
                ('test_line_1',              235.0),
                ('Partner A',                 55.0),
                ('Partner B',                 50.0),
                ('2 more',                   130.0),
            ],
            options,
        )

    def test_subformula_rounding(self):
        """ Test the round subformula in a variety of settings. """
        self.env.company.account_fiscal_country_id = self.fake_country

        # Round to the nearest integer, using the default HALF-DOWN
        test_1 = self._prepare_test_report_line(
            self._prepare_test_expression_external('sum', [self._prepare_test_external_values(98745.50, '2020-01-01')], label='external_decimal'),
            self._prepare_test_expression_aggregation('test_1.external_decimal', subformula='round(0)'),
            name='test_1', code='test_1',
        )
        # Round to the nearest integer, using HALF-UP
        test_2 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.external_decimal', subformula='round(0, HALF-UP)'),
            name='test_2', code='test_2',
        )
        # Round to the nearest integer, using HALF-EVEN
        test_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.external_decimal', subformula='round(0, HALF-EVEN)'),
            name='test_3', code='test_3',
        )
        # Round to the nearest integer, using UP
        test_4 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.external_decimal', subformula='round(0, UP)'),
            name='test_4', code='test_4',
        )
        # Round to the nearest integer, using DOWN
        test_5 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.external_decimal', subformula='round(0, DOWN)'),
            name='test_5', code='test_5',
        )
        # Round to the tenth, using HALF-DOWN
        test_6 = self._prepare_test_report_line(
            self._prepare_test_expression_external('sum', [self._prepare_test_external_values(98745.00, '2020-01-01')], label='external_decimal'),
            self._prepare_test_expression_aggregation('test_6.external_decimal', subformula='round(-1)'),
            name='test_6', code='test_6',
        )
        # Round to the tenth, using HALF-UP
        test_7 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.external_decimal', subformula='round(-1, HALF-UP)'),
            name='test_7', code='test_7',
        )
        # Round to the hundredth
        test_8 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.external_decimal', subformula='round(-2)'),
            name='test_8', code='test_8',
        )

        report = self._create_report(
            [
                test_1, test_2, test_3, test_4, test_5, test_6, test_7, test_8,
            ],
            country_id=self.fake_country.id,
        )

        # Check the values.
        options = self._generate_options(report, '2020-01-01', '2020-01-01')
        report_lines = report._get_lines(options)
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_lines,
            [   0,                    1],
            [
                ('test_1',            98745.00),
                ('test_2',            98746.00),
                ('test_3',            98746.00),
                ('test_4',            98746.00),
                ('test_5',            98745.00),
                ('test_6',            98740.00),
                ('test_7',            98750.00),
                ('test_8',            98700.00),
            ],
            options,
        )

    def test_engine_aggregation_if_other_expr_zero(self):
        """ Test the correctness of the "if_other_expr_xx" when the bound is zero. """
        self.env.company.account_fiscal_country_id = self.fake_country

        # Prepare two simple expressions with 2500 and 0 respectively
        test_1 = self._prepare_test_report_line(
            self._prepare_test_expression_external('sum', [self._prepare_test_external_values(2500, '2020-01-01')], label='balance'),
            name='test_1', code='test_1',
        )
        test_2 = self._prepare_test_report_line(
            self._prepare_test_expression_external('sum', [self._prepare_test_external_values(0, '2020-01-01')], label='balance'),
            name='test_2', code='test_2',
        )
        # And an aggregation which takes test_1 only if test_2 is below 50
        test_3 = self._prepare_test_report_line(
            self._prepare_test_expression_aggregation('test_1.balance', subformula='if_other_expr_below(test_2.balance, USD(50))'),
            name='test_3', code='test_3',
        )

        report = self._create_report(
            [
                test_1, test_2, test_3,
            ],
            country_id=self.fake_country.id,
        )

        # Check the values.
        options = self._generate_options(report, '2020-01-01', '2020-01-01')
        report_lines = report._get_lines(options)
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            report_lines,
            [   0,                    1],
            [
                ('test_1',            2500.00),
                ('test_2',            0.00),
                ('test_3',            2500.00),
            ],
            options,
        )

    def test_account_name_added_in_account_code_grouping(self):
        company_a = self.env['res.company'].sudo().create({
            'name': "Company A",
        })
        company_b = self.env['res.company'].sudo().create({
            'name': "Company B",
        })
        context = {
            **self.env.context,
            'allowed_company_ids': [company_a.id, company_b.id],
        }
        journal_vals = {
            'name': "Misc",
            'type': 'general',
            'code': "MSC",
        }
        AccountJournal = self.env['account.journal'].with_context(context)
        AccountJournal.create(journal_vals | {'company_id': company_a.id})
        AccountJournal.with_company(company_b).create(journal_vals | {'company_id': company_b.id})

        AccountAccount = self.env['account.account'].with_context(context)
        account_a = AccountAccount.create({
            'name': "Account A",
            'code': "100000",
            'company_ids': company_a.ids,
        })
        counterpart_account_a = AccountAccount.create({
            'name': "Some account",
            'code': "200000",
            'company_ids': company_a.ids,
        })
        account_b1 = AccountAccount.create({
            'name': "Mapping to Account A code",
            'code': "300000",
            'company_ids': company_b.ids,
        })
        account_b2 = AccountAccount.create({
            'name': "Mapping to a code that doesn't exist in company A",
            'code': "400000",
            'company_ids': company_b.ids,
        })
        account_b3 = AccountAccount.create({
            'name': "No mapping in company A",
            'code': "500000",
            'company_ids': company_b.ids,
        })

        account_b1.code = account_a.code
        account_b2.code = "600000"

        date = '2025-01-01'

        AccountMove = self.env['account.move'].with_context(context)
        AccountMove.create({
            'move_type': 'entry',
            'date': date,
            'line_ids': [
                Command.create({
                    'account_id': account_a.id,
                    'balance': 20,
                }),
                Command.create({
                    'account_id': counterpart_account_a.id,
                    'balance': -20,
                }),
            ],
            'company_id': company_a.id,
        }).action_post()
        AccountMove.create({
            'move_type': 'entry',
            'date': date,
            'line_ids': [
                Command.create({
                    'account_id': account_b1.id,
                    'balance': 30,
                }),
                Command.create({
                    'account_id': account_b2.id,
                    'balance': 70,
                }),
                Command.create({
                    'account_id': account_b3.id,
                    'balance': -100,
                }),
            ],
            'company_id': company_b.id,
        }).action_post()

        report = self.env['account.report'].with_context(context).create({
            'name': "Simple Report",
            'filter_multi_company': 'selector',
            'column_ids': [Command.create({
                'name': "Balance",
                'expression_label': 'balance',
            })],
            'line_ids': [Command.create({
                'name': "The line",
                'groupby': 'account_code',
                'foldability': 'always_unfolded',
                'expression_ids': [Command.create({
                    'label': 'balance',
                    'engine': 'domain',
                    'formula': [],
                    'subformula': 'sum',
                })],
            })],
        })
        options = self._generate_options(report, date, date)
        lines = report._get_lines(options)

        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            lines,
            [   0,                                                                       1],
            [
                (report.line_ids.name,                                                   0),
                (f'{account_a.code} {account_a.name}',                                  50),
                (f'{counterpart_account_a.code} {counterpart_account_a.name}',         -20),
                (account_b2.code,                                                       70),
                ('Undefined',                                                         -100),
            ],
            options,
        )

    def test_consolidated_report_includes_unmapped_accounts_from_other_companies(self):
        company_a = self.env['res.company'].sudo().create({
            'name': "Company A",
        })
        company_b = self.env['res.company'].sudo().create({
            'name': "Company B",
        })

        context = {
            **self.env.context,
            'allowed_company_ids': [company_a.id, company_b.id],
        }
        journal_vals = {
            'name': "Misc",
            'type': 'general',
            'code': "MSC",
        }
        AccountJournal = self.env['account.journal'].with_context(context)
        AccountJournal.create(journal_vals | {'company_id': company_a.id})
        AccountJournal.with_company(company_b).create(journal_vals | {'company_id': company_b.id})

        AccountAccount = self.env['account.account'].with_context(context)
        account_tag = self.env['account.account.tag']._load_records([
            {
                'xml_id': 'account_reports.account_codes_engine_test_tag1',
                'noupdate': True,
                'values': {
                    'name': "account_codes test tag 1",
                    'applicability': 'accounts',
                },
            }
        ])
        account_a = AccountAccount.create({
            'name': "Account A",
            'code': "100000",
            'company_ids': company_a.ids,
            'tag_ids': [(4, account_tag.id)],
        })
        counterpart_account_a = AccountAccount.create({
            'name': "Counterpart A",
            'code': "200000",
            'company_ids': company_a.ids,
            'tag_ids': [(4, account_tag.id)],
        })
        account_b = AccountAccount.create({
            'name': "Account B",
            'code': "500000",
            'company_ids': company_b.ids,
            'tag_ids': [(4, account_tag.id)],
        })
        counterpart_account_b = AccountAccount.create({
            'name': "Counterpart B",
            'code': "600000",
            'company_ids': company_b.ids,
            'tag_ids': [(4, account_tag.id)],
        })

        date = '2026-01-01'

        AccountMove = self.env['account.move'].with_context(context)
        AccountMove.create({
            'move_type': 'entry',
            'date': date,
            'line_ids': [
                Command.create({
                    'account_id': account_a.id,
                    'balance': 100,
                }),
                Command.create({
                    'account_id': counterpart_account_a.id,
                    'balance': -100,
                }),
            ],
            'company_id': company_a.id,
        }).action_post()
        AccountMove.create({
            'move_type': 'entry',
            'date': date,
            'line_ids': [
                Command.create({
                    'account_id': account_b.id,
                    'balance': 1000,
                }),
                Command.create({
                    'account_id': counterpart_account_b.id,
                    'balance': -1000,
                }),
            ],
            'company_id': company_b.id,
        }).action_post()

        report = self.env['account.report'].with_context(context).create({
            'name': "Simple Report",
            'filter_multi_company': 'selector',
            'column_ids': [Command.create({
                'name': "Balance",
                'expression_label': 'balance',
            })],
            'line_ids': [Command.create({
                'name': "The line",
                'groupby': 'account_id',
                'foldability': 'always_unfolded',
                'expression_ids': [Command.create({
                    'label': 'balance',
                    'engine': 'account_codes',
                    'formula': "tag(account_reports.account_codes_engine_test_tag1)",
                })],
            })],
        })
        options = self._generate_options(report, date, date)
        lines = report._get_lines(options)
        self.assertLinesValues(
            # pylint: disable=bad-whitespace
            lines,
            [   0,                                                                       1],
            [
                (report.line_ids.name,                                                   0),
                (f'{account_a.code} {account_a.name}',                                  100),
                (f'{counterpart_account_a.code} {counterpart_account_a.name}',         -100),
                (f'{account_b.name}',                                                  1000),
                (f'{counterpart_account_b.name}',                                     -1000),
            ],
            options,
        )
